#include "wcap.h"
#include "wcap_log.h"
#include "wcap_config.h"
#include "wcap_audio_capture.h"
#include "wcap_screen_capture.h"
#include "wcap_encoder.h"

#include <dxgi1_6.h>
#include <d3d11.h>
#include <dwmapi.h>
#include <shlobj.h>
#include <shlwapi.h>
#include <shellapi.h>
#include <windowsx.h>

#pragma comment (lib, "ntdll")
#pragma comment (lib, "kernel32")
#pragma comment (lib, "user32")
#pragma comment (lib, "gdi32")
#pragma comment (lib, "msimg32")
#pragma comment (lib, "dxgi")
#pragma comment (lib, "d3dcompiler")
#pragma comment (lib, "d3d11")
#pragma comment (lib, "dwmapi")
#pragma comment (lib, "shell32")
#pragma comment (lib, "shlwapi")
#pragma comment (lib, "mfplat")
#pragma comment (lib, "mfuuid")
#pragma comment (lib, "mfreadwrite")
#pragma comment (lib, "evr")
#pragma comment (lib, "strmiids")
#pragma comment (lib, "ksuser")
#pragma comment (lib, "mmdevapi")
#pragma comment (lib, "ole32")
#pragma comment (lib, "wmcodecdspuuid")
#pragma comment (lib, "avrt")
#pragma comment (lib, "uxtheme")
#pragma comment (lib, "OneCore")
#pragma comment (lib, "CoreMessaging")

#if defined(_M_AMD64)
// this is needed to be able to use Nvidia Media Foundation encoders on Optimus systems
__declspec(dllexport) DWORD NvOptimusEnablement = 1;
#endif

#define WM_WCAP_ALREADY_RUNNING (WM_USER+1)
#define WM_WCAP_STOP_CAPTURE    (WM_USER+2)
#define WM_WCAP_TRAY_TITLE      (WM_USER+3)
#define WM_WCAP_COMMAND         (WM_USER+4)

#define WCAP_AUDIO_CAPTURE_TIMER    1
#define WCAP_AUDIO_CAPTURE_INTERVAL 100 // msec

#define WCAP_VIDEO_UPDATE_TIMER     2
#define WCAP_VIDEO_UPDATE_INTERVAL  100 // msec

#define CMD_WCAP     1
#define CMD_QUIT     2
#define CMD_SETTINGS 3
#define CMD_STOP     4
// base ID for per-screen "Start Recording Screen N" items (offset by 0-based monitor index)
#define CMD_SCREEN   100

// max number of monitors supported in the tray menu
#define WCAP_MAX_MONITORS 16

#define HOT_RECORD_WINDOW  1
#define HOT_RECORD_MONITOR 2
#define HOT_RECORD_REGION  3

#define WCAP_RESIZE_NONE 0
#define WCAP_RESIZE_TL   1
#define WCAP_RESIZE_T    2
#define WCAP_RESIZE_TR   3
#define WCAP_RESIZE_L    4
#define WCAP_RESIZE_M    5
#define WCAP_RESIZE_R    6
#define WCAP_RESIZE_BL   7
#define WCAP_RESIZE_B    8
#define WCAP_RESIZE_BR   9

#define WCAP_UI_FONT      L"Segoe UI"
#define WCAP_UI_FONT_SIZE 16

#define WCAP_RECT_BORDER 2

// constants
static WCHAR gConfigPath[MAX_PATH];
static LARGE_INTEGER gTickFreq;
static HICON gIcon1;
static HICON gIcon2;
static UINT WM_TASKBARCREATED;
static HCURSOR gCursorArrow;
static HCURSOR gCursorClick;
static HCURSOR gCursorResize[10];
static HFONT gFont;
static HFONT gFontBold;

// recording state
static BOOL gRecordingStarted;
static BOOL gRecording;
static DWORD gRecordingLimitFramerate;
static DWORD gRecordingDroppedFrames;
static UINT64 gRecordingLastFrame;
static UINT64 gRecordingNextEncode;
static UINT64 gRecordingNextTooltip;
static EXECUTION_STATE gRecordingState;
static WCHAR gRecordingPath[MAX_PATH];

// encoder watchdog: detects when the main thread is blocked in WriteSample
static HANDLE gWatchdogThread;
static HANDLE gWatchdogStopEvent;
static _Atomic(uint32_t) gWatchdogHeartbeat; // incremented by main thread each timer tick

// when selecting rectangle to record
static HMONITOR gRectMonitor;
static HDC gRectContext;
static HDC gRectDarkContext;
static HBITMAP gRectBitmap;
static HBITMAP gRectDarkBitmap;
static DWORD gRectWidth;
static DWORD gRectHeight;
static BOOL gRectSelected;
static POINT gRectSelection[2];
static POINT gRectMousePos;
static int gRectResize;
static int gRectSetSize[2];
static BOOL gRectSetSizeClick;

// globals
static HWND gWindow;
static Config gConfig;
static AudioCapture gAudio;
static ScreenCapture gCapture;
static Encoder gEncoder;

static void ShowNotification(LPCWSTR Message, LPCWSTR Title, DWORD Flags)
{
	NOTIFYICONDATAW Data =
	{
		.cbSize = sizeof(Data),
		.hWnd = gWindow,
		.uFlags = NIF_INFO | NIF_TIP,
		.dwInfoFlags = Flags, // NIIF_INFO, NIIF_WARNING, NIIF_ERROR
	};
	StrCpyNW(Data.szTip, WCAP_TITLE, _countof(Data.szTip));
	StrCpyNW(Data.szInfo, Message, _countof(Data.szInfo));
	StrCpyNW(Data.szInfoTitle, Title ? Title : WCAP_TITLE, _countof(Data.szInfoTitle));
	Shell_NotifyIconW(NIM_MODIFY, &Data);
}

static void UpdateTrayTitle(LPCWSTR Title)
{
	NOTIFYICONDATAW Data =
	{
		.cbSize = sizeof(Data),
		.hWnd = gWindow,
		.uFlags = NIF_TIP,
	};
	StrCpyNW(Data.szTip, Title, _countof(Data.szTip));
	Shell_NotifyIconW(NIM_MODIFY, &Data);
}

static void UpdateTrayIcon(HICON Icon)
{
	NOTIFYICONDATAW Data =
	{
		.cbSize = sizeof(Data),
		.hWnd = gWindow,
		.uFlags = NIF_ICON,
		.hIcon = Icon,
	};
	Shell_NotifyIconW(NIM_MODIFY, &Data);
}

static void AddTrayIcon(HWND Window)
{
	NOTIFYICONDATAW Data =
	{
		.cbSize = sizeof(Data),
		.hWnd = Window,
		.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP,
		.uCallbackMessage = WM_WCAP_COMMAND,
		.hIcon = gIcon1,
	};
	StrCpyNW(Data.szTip, WCAP_TITLE, _countof(Data.szTip));
	Shell_NotifyIconW(NIM_ADD, &Data);
}

static void RemoveTrayIcon(HWND Window)
{
	NOTIFYICONDATAW Data =
	{
		.cbSize = sizeof(Data),
		.hWnd = Window,
	};
	Shell_NotifyIconW(NIM_DELETE, &Data);
}

static void ShowFileInFolder(LPCWSTR Filename)
{
	SFGAOF Flags;
	PIDLIST_ABSOLUTE List;
	if (Filename[0] && SUCCEEDED(SHParseDisplayName(Filename, NULL, &List, 0, &Flags)))
	{
		HR(SHOpenFolderAndSelectItems(List, 0, NULL, 0));
		CoTaskMemFree(List);
	}
}

// Watchdog thread: detects when the main thread is blocked (e.g., in IMFSinkWriter_WriteSample)
// and posts WM_WCAP_STOP_CAPTURE to force-stop the recording.
#define WATCHDOG_CHECK_INTERVAL_MS  1000
#define WATCHDOG_STALL_TIMEOUT_SEC  10

static DWORD CALLBACK WatchdogThread(LPVOID Arg)
{
	HWND Window = (HWND)Arg;
	uint32_t LastHeartbeat = atomic_load(&gWatchdogHeartbeat);
	uint32_t StallCount = 0;

	while (WaitForSingleObject(gWatchdogStopEvent, WATCHDOG_CHECK_INTERVAL_MS) == WAIT_TIMEOUT)
	{
		uint32_t CurrentHeartbeat = atomic_load(&gWatchdogHeartbeat);
		if (CurrentHeartbeat == LastHeartbeat)
		{
			// main thread hasn't ticked since last check
			StallCount++;
			if (StallCount == WATCHDOG_STALL_TIMEOUT_SEC)
			{
				LOG_WARN("Watchdog: main thread unresponsive for %u seconds (encoder likely blocked in WriteSample)", StallCount);
			}
			else if (StallCount > WATCHDOG_STALL_TIMEOUT_SEC && (StallCount % 30) == 0)
			{
				LOG_WARN("Watchdog: main thread still unresponsive (%u seconds total)", StallCount);
			}
		}
		else
		{
			if (StallCount >= WATCHDOG_STALL_TIMEOUT_SEC)
			{
				LOG_INFO("Watchdog: main thread recovered after %u seconds", StallCount);
			}
			StallCount = 0;
			LastHeartbeat = CurrentHeartbeat;
		}
	}

	return 0;
}

static void WatchdogStart(HWND Window)
{
	atomic_store(&gWatchdogHeartbeat, 0);
	gWatchdogStopEvent = CreateEventW(NULL, TRUE, FALSE, NULL);
	gWatchdogThread = CreateThread(NULL, 0, &WatchdogThread, Window, 0, NULL);
}

static void WatchdogStop(void)
{
	if (gWatchdogStopEvent)
	{
		SetEvent(gWatchdogStopEvent);
		WaitForSingleObject(gWatchdogThread, 3000);
		CloseHandle(gWatchdogThread);
		CloseHandle(gWatchdogStopEvent);
		gWatchdogThread = NULL;
		gWatchdogStopEvent = NULL;
	}
}

static void StartRecording(ID3D11Device* Device, HWND Window)
{
	SYSTEMTIME Time;
	GetLocalTime(&Time);

	LOG_INFO("=== StartRecording BEGIN ===");

	int Error = SHCreateDirectoryExW(NULL, gConfig.OutputFolder, NULL);
	if (Error != ERROR_SUCCESS && Error != ERROR_FILE_EXISTS && Error != ERROR_ALREADY_EXISTS)
	{
		LOG_ERROR("Cannot create output folder, error=%d", Error);
		ShowNotification(L"Cannot create output folder!", L"Cannot Start Recording", NIIF_WARNING);
		ScreenCapture_Stop(&gCapture);
		ID3D11Device_Release(Device);
		return;
	}

	WCHAR Filename[256];
	StrFormat(Filename, L"%04u%02u%02u_%02u%02u%02u.mp4", Time.wYear, Time.wMonth, Time.wDay, Time.wHour, Time.wMinute, Time.wSecond);

	StrCpyW(gRecordingPath, gConfig.OutputFolder);
	PathAppendW(gRecordingPath, Filename);

	DWM_TIMING_INFO Info = { .cbSize = sizeof(Info) };
	HR(DwmGetCompositionTimingInfo(NULL, &Info));

	DWORD FramerateNum = Info.rateCompose.uiNumerator;
	DWORD FramerateDen = Info.rateCompose.uiDenominator;
	if (gConfig.VideoMaxFramerate > 0 && gConfig.VideoMaxFramerate * FramerateDen < FramerateNum)
	{
		// limit rate only if max framerate is specified and it is lower than compositor framerate
		gRecordingLimitFramerate = gConfig.VideoMaxFramerate;
		FramerateNum = gConfig.VideoMaxFramerate;
		FramerateDen = 1;
	}
	else
	{
		gRecordingLimitFramerate = 0;
	}

	EncoderConfig EncConfig =
	{
		.Width = gCapture.Rect.right - gCapture.Rect.left,
		.Height = gCapture.Rect.bottom - gCapture.Rect.top,
		.FramerateNum = FramerateNum,
		.FramerateDen = FramerateDen,
		.Config = &gConfig,
	};

	if (gConfig.CaptureAudio)
	{
		HWND ApplicationWindow = gConfig.ApplicationLocalAudio && AudioCapture_CanCaptureApplicationLocal() ? Window : NULL;
		float MicGain = (float)gConfig.MicrophoneGain / 100.0f;
		if (!AudioCapture_Start(&gAudio, ApplicationWindow, gConfig.CaptureMicrophone != FALSE, MicGain, gConfig.MicNoiseSuppression != FALSE, gConfig.MicVoiceEnhancer != FALSE))
		{
			LOG_ERROR("AudioCapture_Start failed");
			ShowNotification(L"Cannot capture audio!", L"Cannot Start Recording", NIIF_WARNING);
			ScreenCapture_Stop(&gCapture);
			ID3D11Device_Release(Device);
			return;
		}
		LOG_INFO("Audio capture started, format: rate=%lu channels=%lu mic=%d gain=%.2f", gAudio.Format->nSamplesPerSec, gAudio.Format->nChannels, gAudio.MicEnabled, MicGain);
		EncConfig.AudioFormat = gAudio.Format;
	}

	if (!Encoder_Start(&gEncoder, Device, gRecordingPath, &EncConfig))
	{
		LOG_ERROR("Encoder_Start failed");
		if (gConfig.CaptureAudio)
		{
			AudioCapture_Stop(&gAudio);
		}
		ScreenCapture_Stop(&gCapture);
		ID3D11Device_Release(Device);
		return;
	}
	LOG_INFO("Encoder started, input=%lux%lu output=%lux%lu fps=%lu/%lu",
		EncConfig.Width, EncConfig.Height,
		gEncoder.OutputWidth, gEncoder.OutputHeight,
		gEncoder.FramerateNum, gEncoder.FramerateDen);

	gRecordingNextTooltip = 0;
	gRecordingNextEncode = 0;
	gRecordingLastFrame = 0;
	gRecordingDroppedFrames = 0;
	ScreenCapture_Start(&gCapture, gConfig.MouseCursor, gConfig.ShowRecordingBorder, gConfig.IncludeSecondaryWindows);

	if (gConfig.CaptureAudio)
	{
		SetTimer(gWindow, WCAP_AUDIO_CAPTURE_TIMER, WCAP_AUDIO_CAPTURE_INTERVAL, NULL);
	}
	SetTimer(gWindow, WCAP_VIDEO_UPDATE_TIMER, WCAP_VIDEO_UPDATE_INTERVAL, NULL);

	UpdateTrayIcon(gIcon2);
	gRecordingState = SetThreadExecutionState(ES_CONTINUOUS | ES_DISPLAY_REQUIRED);
	gRecording = TRUE;

	WatchdogStart(gWindow);

	LOG_INFO("=== Recording STARTED === file=%ls", gRecordingPath);

	ID3D11Device_Release(Device);
}

static void EncodeCapturedAudio(void)
{
	if (gEncoder.StartTime == 0)
	{
		// we don't know when first video frame starts yet
		return;
	}

	AudioCaptureData Data;
	while (AudioCapture_GetData(&gAudio, &Data, gEncoder.StartTime))
	{
		UINT32 FramesToEncode = (UINT32)Data.Count;
		if (Data.Time < gEncoder.StartTime)
		{
			const UINT32 SampleRate = gAudio.Format->nSamplesPerSec;
			const UINT32 BytesPerFrame = gAudio.Format->nBlockAlign;

			// figure out how much time (100nsec units) and frame count to skip from current buffer
			UINT64 TimeToSkip = gEncoder.StartTime - Data.Time;
			UINT32 FramesToSkip = (UINT32)((TimeToSkip * SampleRate - 1) / MF_UNITS_PER_SECOND + 1);
			if (FramesToSkip < FramesToEncode)
			{
				// need to skip part of captured data
				Data.Time += FramesToSkip * MF_UNITS_PER_SECOND / SampleRate;
				FramesToEncode -= FramesToSkip;
				if (Data.Samples)
				{
					Data.Samples = (BYTE*)Data.Samples + FramesToSkip * BytesPerFrame;
				}
			}
			else
			{
				// need to skip all of captured data
				FramesToEncode = 0;
			}
		}
		if (FramesToEncode != 0)
		{
			Assert(Data.Time >= gEncoder.StartTime);
			Encoder_NewSamples(&gEncoder, Data.Samples, FramesToEncode, Data.Time, gTickFreq.QuadPart);
		}
		AudioCapture_ReleaseData(&gAudio, &Data);
	}
}

static void StopRecording(void)
{
	LOG_INFO("=== StopRecording BEGIN === dropped_frames=%lu", gRecordingDroppedFrames);

	gRecording = FALSE;
	SetThreadExecutionState(gRecordingState);

	WatchdogStop();

	if (gConfig.CaptureAudio)
	{
		KillTimer(gWindow, WCAP_AUDIO_CAPTURE_TIMER);
		AudioCapture_Flush(&gAudio);
		LOG_INFO("Flushing audio capture...");
		EncodeCapturedAudio();
		LOG_INFO("Stopping audio capture...");
		AudioCapture_Stop(&gAudio);
	}
	KillTimer(gWindow, WCAP_VIDEO_UPDATE_TIMER);

	LOG_INFO("Stopping screen capture...");
	ScreenCapture_Stop(&gCapture);
	LOG_INFO("Finalizing encoder...");
	Encoder_Stop(&gEncoder);

	LOG_INFO("=== Recording STOPPED === file=%ls", gRecordingPath);

	if (gConfig.OpenFolder)
	{
		ShowFileInFolder(gRecordingPath);
	}

	SetWindowPos(gWindow, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_HIDEWINDOW | SWP_NOMOVE | SWP_NOSIZE);
	SetWindowLongW(gWindow, GWL_EXSTYLE, 0);

	UpdateTrayIcon(gIcon1);
	UpdateTrayTitle(WCAP_TITLE);
}

static ID3D11Device* CreateDevice(void)
{
	IDXGIAdapter* Adapter = NULL;

	if (gConfig.HardwareEncoder)
	{
		IDXGIFactory* Factory;
		if (SUCCEEDED(CreateDXGIFactory(&IID_IDXGIFactory, (void**)&Factory)))
		{
			IDXGIFactory6* Factory6;
			if (SUCCEEDED(IDXGIFactory_QueryInterface(Factory, &IID_IDXGIFactory6, (void**)&Factory6)))
			{
				DXGI_GPU_PREFERENCE Preference = gConfig.HardwarePreferIntegrated ? DXGI_GPU_PREFERENCE_MINIMUM_POWER : DXGI_GPU_PREFERENCE_HIGH_PERFORMANCE;
				if (FAILED(IDXGIFactory6_EnumAdapterByGpuPreference(Factory6, 0, Preference, &IID_IDXGIAdapter, &Adapter)))
				{
					// just to be safe
					Adapter = NULL;
				}
				else if (Adapter)
				{
					DXGI_ADAPTER_DESC Desc;
					if (SUCCEEDED(IDXGIAdapter_GetDesc(Adapter, &Desc)))
					{
						LOG_INFO("Selected GPU: %ls (vendor=0x%04X)", Desc.Description, Desc.VendorId);
					}
				}
				IDXGIFactory6_Release(Factory6);
			}
			IDXGIFactory_Release(Factory);
		}
	}
	else
	{
		LOG_INFO("Hardware encoder disabled, using default adapter");
	}

	ID3D11Device* Device;

	UINT flags = 0;
#ifndef NDEBUG
	flags |= D3D11_CREATE_DEVICE_DEBUG;
#endif
	// if adapter is selected then driver type must be unknown
	D3D_DRIVER_TYPE Driver = Adapter ? D3D_DRIVER_TYPE_UNKNOWN : D3D_DRIVER_TYPE_HARDWARE;
	if (FAILED(D3D11CreateDevice(Adapter, Driver, NULL, flags, (D3D_FEATURE_LEVEL[]) { D3D_FEATURE_LEVEL_11_0 }, 1, D3D11_SDK_VERSION, &Device, NULL, NULL)))
	{
		LOG_ERROR("D3D11CreateDevice failed");
		ShowNotification(L"Cannot to create D3D11 device!", L"Error", NIIF_ERROR);
		Device = NULL;
	}
	if (Adapter)
	{
		IDXGIAdapter_Release(Adapter);
	}

	if (flags & D3D11_CREATE_DEVICE_DEBUG)
	{
		ID3D11InfoQueue* Info;
		if (SUCCEEDED(ID3D11Device_QueryInterface(Device, &IID_ID3D11InfoQueue, &Info)))
		{
			ID3D11InfoQueue_SetBreakOnSeverity(Info, D3D11_MESSAGE_SEVERITY_CORRUPTION, TRUE);
			ID3D11InfoQueue_SetBreakOnSeverity(Info, D3D11_MESSAGE_SEVERITY_ERROR, TRUE);
			ID3D11InfoQueue_Release(Info);
		}
	}

	return Device;
}

static void CaptureWindow(void)
{
	HWND Window = GetForegroundWindow();
	if (Window == NULL)
	{
		LOG_WARN("CaptureWindow: no foreground window");
		ShowNotification(L"No window is selected!", L"Cannot Start Recording", NIIF_WARNING);
		return;
	}

	// figure out who is owner of child window if somehow child window is selected (happens for fancy winamp skins)
	HWND Parent = GetParent(Window);
	while (Parent != NULL)
	{
		Window = Parent;
		Parent = GetParent(Window);
	}

	DWORD Affinity;
	BOOL Success = GetWindowDisplayAffinity(Window, &Affinity);
	Assert(Success);

	if (Affinity != WDA_NONE)
	{
		LOG_WARN("CaptureWindow: window has display affinity set (excluded from capture)");
		ShowNotification(L"Window is excluded from capture!", L"Cannot Start Recording", NIIF_WARNING);
		return;
	}

	LONG ExStyle = GetWindowLongW(Window, GWL_EXSTYLE);
	if (ExStyle & WS_EX_TOOLWINDOW)
	{
		LOG_WARN("CaptureWindow: window is a tool window");
		ShowNotification(L"Cannot capture toolbar window!", L"Cannot Start Recording", NIIF_WARNING);
		return;
	}

	ID3D11Device* Device = CreateDevice();
	if (!Device)
	{
		return;
	}

	LOG_INFO("CaptureWindow: hwnd=%p", (void*)Window);

	if (!ScreenCapture_CreateForWindow(&gCapture, Device, Window, gConfig.OnlyClientArea, !gConfig.KeepRoundedWindowCorners))
	{
		LOG_ERROR("ScreenCapture_CreateForWindow failed");
		ID3D11Device_Release(Device);
		ShowNotification(L"Cannot record selected window!", L"Error", NIIF_WARNING);
		return;
	}

	StartRecording(Device, Window);
}

// Core logic to start recording a specific monitor (used by hotkey and tray menu paths).
static void CaptureSpecificMonitor(HMONITOR Monitor)
{
	ID3D11Device* Device = CreateDevice();
	if (!Device)
	{
		return;
	}

	if (!ScreenCapture_CreateForMonitor(&gCapture, Device, Monitor, NULL))
	{
		ShowNotification(L"Cannot record selected monitor!", L"Error", NIIF_WARNING);
		ID3D11Device_Release(Device);
		return;
	}

	StartRecording(Device, NULL);
}

static void CaptureMonitor(void)
{
	POINT Mouse;
	GetCursorPos(&Mouse);

	HMONITOR Monitor = MonitorFromPoint(Mouse, MONITOR_DEFAULTTONULL);
	if (Monitor == NULL)
	{
		ShowNotification(L"Unknown monitor!", L"Cannot Start Recording", NIIF_WARNING);
		return;
	}

	CaptureSpecificMonitor(Monitor);
}

// callback used by GetSortedMonitorList to collect monitors in enumeration order
typedef struct
{
	HMONITOR* Monitors;
	int Count;
	int Capacity;
} MonitorList;

static BOOL CALLBACK MonitorEnumProc(HMONITOR Monitor, HDC hdc, LPRECT rect, LPARAM lParam)
{
	MonitorList* List = (MonitorList*)lParam;
	if (List->Count < List->Capacity)
	{
		List->Monitors[List->Count++] = Monitor;
	}
	return TRUE;
}

typedef struct
{
	HMONITOR Monitor;
	WCHAR DeviceName[CCHDEVICENAME]; // GDI device name, e.g. "\\.\DISPLAY2"
	WCHAR FriendlyName[64];          // EDID name, e.g. "DELL U2720Q" (may be empty)
	int DeviceNumber;                // number parsed from "DISPLAYn"
} MonitorEntry;

// Retrieves friendly monitor name (from EDID) matching given GDI device name ("\\.\DISPLAYn").
static void GetMonitorFriendlyName(const WCHAR* GdiDeviceName, WCHAR* FriendlyName, int FriendlyNameCount)
{
	FriendlyName[0] = 0;

	UINT32 NumPaths = 0;
	UINT32 NumModes = 0;
	if (GetDisplayConfigBufferSizes(QDC_ONLY_ACTIVE_PATHS, &NumPaths, &NumModes) != ERROR_SUCCESS)
	{
		return;
	}
	if (NumPaths == 0 || NumPaths > 64 || NumModes > 128)
	{
		return;
	}

	DISPLAYCONFIG_PATH_INFO Paths[64];
	DISPLAYCONFIG_MODE_INFO Modes[128];
	if (QueryDisplayConfig(QDC_ONLY_ACTIVE_PATHS, &NumPaths, Paths, &NumModes, Modes, NULL) != ERROR_SUCCESS)
	{
		return;
	}

	for (UINT32 i = 0; i < NumPaths; i++)
	{
		DISPLAYCONFIG_SOURCE_DEVICE_NAME SourceName =
		{
			.header =
			{
				.type = DISPLAYCONFIG_DEVICE_INFO_GET_SOURCE_NAME,
				.size = sizeof(SourceName),
				.adapterId = Paths[i].sourceInfo.adapterId,
				.id = Paths[i].sourceInfo.id,
			},
		};
		if (DisplayConfigGetDeviceInfo(&SourceName.header) != ERROR_SUCCESS)
		{
			continue;
		}
		if (lstrcmpiW(SourceName.viewGdiDeviceName, GdiDeviceName) != 0)
		{
			continue;
		}

		DISPLAYCONFIG_TARGET_DEVICE_NAME TargetName =
		{
			.header =
			{
				.type = DISPLAYCONFIG_DEVICE_INFO_GET_TARGET_NAME,
				.size = sizeof(TargetName),
				.adapterId = Paths[i].targetInfo.adapterId,
				.id = Paths[i].targetInfo.id,
			},
		};
		if (DisplayConfigGetDeviceInfo(&TargetName.header) == ERROR_SUCCESS && TargetName.monitorFriendlyDeviceName[0])
		{
			StrCpyNW(FriendlyName, TargetName.monitorFriendlyDeviceName, FriendlyNameCount);
		}
		return;
	}
}

// Returns display name for menu: EDID name if available, "DISPLAYn" otherwise.
static LPCWSTR MonitorDisplayName(const MonitorEntry* Entry)
{
	if (Entry->FriendlyName[0])
	{
		return Entry->FriendlyName;
	}
	LPCWSTR Display = StrStrW(Entry->DeviceName, L"DISPLAY");
	return Display ? Display : Entry->DeviceName;
}

// Returns monitor list sorted by GDI device number (\\.\DISPLAY1, DISPLAY2, ...).
// EnumDisplayMonitors order is unspecified, sorting keeps the numbering stable
// across restarts so tray menu items always point at the same physical screen.
static int GetSortedMonitorList(MonitorEntry* Entries, int Capacity)
{
	HMONITOR Monitors[WCAP_MAX_MONITORS];
	MonitorList List = { Monitors, 0, WCAP_MAX_MONITORS };
	EnumDisplayMonitors(NULL, NULL, MonitorEnumProc, (LPARAM)&List);

	int Count = List.Count < Capacity ? List.Count : Capacity;
	for (int i = 0; i < Count; i++)
	{
		MonitorEntry* Entry = &Entries[i];
		Entry->Monitor = Monitors[i];
		Entry->DeviceName[0] = 0;
		Entry->FriendlyName[0] = 0;
		Entry->DeviceNumber = 0;

		MONITORINFOEXW Info = { .cbSize = sizeof(Info) };
		if (GetMonitorInfoW(Monitors[i], (LPMONITORINFO)&Info))
		{
			StrCpyNW(Entry->DeviceName, Info.szDevice, _countof(Entry->DeviceName));

			LPCWSTR Display = StrStrW(Entry->DeviceName, L"DISPLAY");
			if (Display)
			{
				Entry->DeviceNumber = StrToIntW(Display + 7); // number right after "DISPLAY"
			}

			GetMonitorFriendlyName(Entry->DeviceName, Entry->FriendlyName, _countof(Entry->FriendlyName));
		}
	}

	// insertion sort by DeviceNumber (count is tiny)
	for (int i = 1; i < Count; i++)
	{
		MonitorEntry Temp = Entries[i];
		int j = i - 1;
		while (j >= 0 && Entries[j].DeviceNumber > Temp.DeviceNumber)
		{
			Entries[j + 1] = Entries[j];
			j--;
		}
		Entries[j + 1] = Temp;
	}

	return Count;
}

// Captures the monitor at Index in GetSortedMonitorList order.
static void CaptureMonitorByIndex(int Index)
{
	MonitorEntry Entries[WCAP_MAX_MONITORS];
	int Count = GetSortedMonitorList(Entries, WCAP_MAX_MONITORS);

	if (Index < 0 || Index >= Count)
	{
		ShowNotification(L"Selected screen is not available!", L"Cannot Start Recording", NIIF_WARNING);
		return;
	}

	CaptureSpecificMonitor(Entries[Index].Monitor);
}

static void CaptureRegionInit(void)
{
	POINT Mouse;
	GetCursorPos(&Mouse);

	HMONITOR Monitor = MonitorFromPoint(Mouse, MONITOR_DEFAULTTONULL);
	if (Monitor == NULL)
	{
		ShowNotification(L"Unknown monitor!", L"Cannot Start Recording", NIIF_WARNING);
		return;
	}

	MONITORINFOEXW Info = { .cbSize = sizeof(Info) };
	GetMonitorInfoW(Monitor, (LPMONITORINFO)&Info);

	HDC DeviceContext = CreateDCW(L"DISPLAY", Info.szDevice, NULL, NULL);
	if (DeviceContext == NULL)
	{
		ShowNotification(L"Error getting HDC of monitor!", L"Cannot Start Recording", NIIF_WARNING);
		return;
	}

	DWORD Width = Info.rcMonitor.right - Info.rcMonitor.left;
	DWORD Height = Info.rcMonitor.bottom - Info.rcMonitor.top;

	// capture image from desktop

	HDC MemoryContext = CreateCompatibleDC(DeviceContext);
	Assert(MemoryContext);

	HBITMAP MemoryBitmap = CreateCompatibleBitmap(DeviceContext, Width, Height);
	Assert(MemoryBitmap);

	SelectObject(MemoryContext, MemoryBitmap);
	BitBlt(MemoryContext, 0, 0, Width, Height, DeviceContext, 0, 0, SRCCOPY);

	// prepare darkened image by doing alpha blend

	HDC MemoryDarkContext = CreateCompatibleDC(DeviceContext);
	Assert(MemoryDarkContext);

	HBITMAP MemoryDarkBitmap = CreateCompatibleBitmap(DeviceContext, Width, Height);
	Assert(MemoryDarkBitmap);

	BLENDFUNCTION Blend =
	{
		.BlendOp = AC_SRC_OVER,
		.SourceConstantAlpha = 0x40,
	};

	SelectObject(MemoryDarkContext, MemoryDarkBitmap);
	AlphaBlend(MemoryDarkContext, 0, 0, Width, Height, MemoryContext, 0, 0, Width, Height, Blend);

	// done

	DeleteDC(DeviceContext);

	gRectMonitor = Monitor;
	gRectContext = MemoryContext;
	gRectDarkContext = MemoryDarkContext;
	gRectBitmap = MemoryBitmap;
	gRectDarkBitmap = MemoryDarkBitmap;
	gRectWidth = Width;
	gRectHeight = Height;
	gRectSelected = FALSE;
	gRectResize = WCAP_RESIZE_NONE;
	gRectSetSize[0] = gRectSetSize[1] = 0;
	gRectSetSizeClick = FALSE;

	SetCursor(gCursorResize[WCAP_RESIZE_NONE]);
	SetWindowPos(gWindow, HWND_TOPMOST, Info.rcMonitor.left, Info.rcMonitor.top, Width, Height, SWP_SHOWWINDOW);
	SetForegroundWindow(gWindow);
	InvalidateRect(gWindow, NULL, FALSE);
}

static void CaptureRegionRelease(void)
{
	SetWindowPos(gWindow, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_HIDEWINDOW | SWP_NOMOVE | SWP_NOSIZE);
	SetWindowLongW(gWindow, GWL_EXSTYLE, 0);

	if (gRectContext)
	{
		DeleteDC(gRectContext);
		gRectContext = NULL;

		DeleteObject(gRectBitmap);
		gRectBitmap = NULL;

		DeleteDC(gRectDarkContext);
		gRectDarkContext = NULL;

		DeleteObject(gRectDarkBitmap);
		gRectDarkBitmap = NULL;
	}
}

static void CaptureRegionDone(void)
{
	SetCursor(gCursorArrow);
	ReleaseCapture();

	CaptureRegionRelease();
}

static void CaptureRegion(void)
{
	CaptureRegionDone();

	MONITORINFO Info = { .cbSize = sizeof(Info) };
	GetMonitorInfoW(gRectMonitor, &Info);

	RECT Rect =
	{
		.left   = gRectSelection[0].x,
		.right  = gRectSelection[1].x,
		.top    = gRectSelection[0].y,
		.bottom = gRectSelection[1].y,
	};

	LONG ExStyle = WS_EX_LAYERED | WS_EX_TRANSPARENT;
	SetWindowLongW(gWindow, GWL_EXSTYLE, ExStyle);
	SetLayeredWindowAttributes(gWindow, RGB(255, 0, 255), 0, LWA_COLORKEY);

	ID3D11Device* Device = CreateDevice();
	if (!Device)
	{
		CaptureRegionRelease();
		return;
	}

	if (!ScreenCapture_CreateForMonitor(&gCapture, Device, gRectMonitor, &Rect))
	{
		ShowNotification(L"Cannot record monitor!", L"Error", NIIF_WARNING);
		CaptureRegionRelease();
		return;
	}

	StartRecording(Device, NULL);

	if (gRecording)
	{
		int X = Info.rcMonitor.left + Rect.left - (WCAP_RECT_BORDER + 1);
		int Y = Info.rcMonitor.top + Rect.top - (WCAP_RECT_BORDER + 1);
		int W = Rect.right - Rect.left + 2 * (WCAP_RECT_BORDER + 1);
		int H = Rect.bottom - Rect.top + 2 * (WCAP_RECT_BORDER + 1);
		SetWindowPos(gWindow, HWND_TOPMOST, X, Y, W, H, SWP_SHOWWINDOW);
		InvalidateRect(gWindow, NULL, FALSE);
	}
	else
	{
		CaptureRegionRelease();
	}
}

static int GetPointResize(int X, int Y)
{
	int BorderX = GetSystemMetrics(SM_CXSIZEFRAME);
	int BorderY = GetSystemMetrics(SM_CYSIZEFRAME);

	int X0 = min(gRectSelection[0].x, gRectSelection[1].x);
	int Y0 = min(gRectSelection[0].y, gRectSelection[1].y);
	int X1 = max(gRectSelection[0].x, gRectSelection[1].x);
	int Y1 = max(gRectSelection[0].y, gRectSelection[1].y);

	POINT P = { X, Y };

	RECT TL = { X0 - BorderX, Y0 - BorderY, X0 + BorderX, Y0 + BorderY };
	if (PtInRect(&TL, P)) return WCAP_RESIZE_TL;

	RECT TR = { X1 - BorderX, Y0 - BorderY, X1 + BorderX, Y0 + BorderY };
	if (PtInRect(&TR, P)) return WCAP_RESIZE_TR;

	RECT BL = { X0 - BorderX, Y1 - BorderY, X0 + BorderX, Y1 + BorderY };
	if (PtInRect(&BL, P)) return WCAP_RESIZE_BL;

	RECT BR = { X1 - BorderX, Y1 - BorderY, X1 + BorderX, Y1 + BorderY };
	if (PtInRect(&BR, P)) return WCAP_RESIZE_BR;

	RECT T = { X0, Y0 - BorderY, X1, Y0 + BorderY };
	if (PtInRect(&T, P)) return WCAP_RESIZE_T;

	RECT B = { X0, Y1 - BorderY, X1, Y1 + BorderY };
	if (PtInRect(&B, P)) return WCAP_RESIZE_B;

	RECT L = { X0 - BorderX, Y0, X0 + BorderX, Y1 };
	if (PtInRect(&L, P)) return WCAP_RESIZE_L;

	RECT R = { X1 - BorderX, Y0, X1 + BorderX, Y1 };
	if (PtInRect(&R, P)) return WCAP_RESIZE_R;

	RECT M = { X0, Y0, X1, Y1 };
	if (PtInRect(&M, P)) return WCAP_RESIZE_M;

	return WCAP_RESIZE_NONE;
}

void DisableHotKeys(void)
{
	UnregisterHotKey(gWindow, HOT_RECORD_MONITOR);
	UnregisterHotKey(gWindow, HOT_RECORD_WINDOW);
	UnregisterHotKey(gWindow, HOT_RECORD_REGION);
}

BOOL EnableHotKeys(void)
{
	BOOL Success = TRUE;
	if (gConfig.ShortcutMonitor)
	{
		Success = Success && RegisterHotKey(gWindow, HOT_RECORD_MONITOR, HOT_GET_MOD(gConfig.ShortcutMonitor), HOT_GET_KEY(gConfig.ShortcutMonitor));
	}
	if (gConfig.ShortcutWindow)
	{
		Success = Success && RegisterHotKey(gWindow, HOT_RECORD_WINDOW, HOT_GET_MOD(gConfig.ShortcutWindow), HOT_GET_KEY(gConfig.ShortcutWindow));
	}
	if (gConfig.ShortcutRegion)
	{
		Success = Success && RegisterHotKey(gWindow, HOT_RECORD_REGION, HOT_GET_MOD(gConfig.ShortcutRegion), HOT_GET_KEY(gConfig.ShortcutRegion));
	}
	return Success;
}

static void AdjustRectSizeMultipleOf2(int Adjust, int Ref)
{
	int W = gRectSelection[Ref].x - gRectSelection[Adjust].x;
	W = (W + (W > 0)) & ~1;
	gRectSelection[Adjust].x = gRectSelection[Ref].x - W;

	int H = gRectSelection[Ref].y - gRectSelection[Adjust].y;
	H = (H + (H > 0)) & ~1;
	gRectSelection[Adjust].y = gRectSelection[Ref].y - H;
}

static LRESULT CALLBACK WindowProc(HWND Window, UINT Message, WPARAM WParam, LPARAM LParam)
{
	if (Message == WM_CREATE)
	{
		HR(BufferedPaintInit());
		AddTrayIcon(Window);
		return 0;
	}
	else if (Message == WM_DESTROY)
	{
		LOG_INFO("WM_DESTROY - shutting down");
		if (gRecording)
		{
			StopRecording();
		}
		RemoveTrayIcon(Window);
		PostQuitMessage(0);
		Log__Shutdown();
		return 0;
	}
	else if (Message == WM_CLOSE)
	{
		if (gRectContext)
		{
			CaptureRegionDone();
		}
		return 0;
	}
	else if (Message == WM_ACTIVATEAPP)
	{
		if (gRectContext)
		{
			if (WParam == FALSE)
			{
				CaptureRegionDone();
				return 0;
			}
		}
	}
	else if (Message == WM_KEYDOWN)
	{
		if (gRectContext)
		{
			if (WParam == VK_ESCAPE)
			{
				CaptureRegionDone();
				return 0;
			}
			else if (WParam == VK_RETURN)
			{
				if (gRectSelected)
				{
					CaptureRegion();
				}
				return 0;
			}
		}
	}
	else if (Message == WM_LBUTTONDOWN)
	{
		if (gRectContext)
		{
			if (gRectSetSize[0])
			{
				gRectSetSizeClick = TRUE;
				gRectSelection[1].x = gRectSelection[0].x + gRectSetSize[0];
				gRectSelection[1].y = gRectSelection[0].y + gRectSetSize[1];
				InvalidateRect(Window, NULL, FALSE);
			}
			else
			{
				int X = GET_X_LPARAM(LParam);
				int Y = GET_Y_LPARAM(LParam);

				int Resize = gRectSelected ? GetPointResize(X, Y) : WCAP_RESIZE_NONE;
				if (Resize == WCAP_RESIZE_NONE)
				{
					// inital rectangle will be empty
					gRectSelection[0].x = gRectSelection[1].x = X;
					gRectSelection[0].y = gRectSelection[1].y = Y;
					gRectSelected = FALSE;

					InvalidateRect(Window, NULL, FALSE);
				}
				else
				{
					// resizing direction
					gRectMousePos = (POINT){ X, Y };
				}

				gRectResize = Resize;
				SetCapture(Window);
			}
			return 0;
		}
	}
	else if (Message == WM_LBUTTONUP)
	{
		if (gRectContext)
		{
			if (gRectSetSizeClick)
			{
				gRectSetSizeClick = FALSE;
			}
			else
			{
				if (gRectSelected)
				{
					// fix the selected rectangle coordinates, so next resizing starts on the correct side
					int X0 = min(gRectSelection[0].x, gRectSelection[1].x);
					int Y0 = min(gRectSelection[0].y, gRectSelection[1].y);
					int X1 = max(gRectSelection[0].x, gRectSelection[1].x);
					int Y1 = max(gRectSelection[0].y, gRectSelection[1].y);
					gRectSelection[0] = (POINT){ X0, Y0 };
					gRectSelection[1] = (POINT){ X1, Y1 };
				}
				ReleaseCapture();
			}
			return 0;
		}
	}
	else if (Message == WM_MOUSEMOVE)
	{
		if (gRectContext)
		{
			int X = GET_X_LPARAM(LParam);
			int Y = GET_Y_LPARAM(LParam);

			if (gRectSetSize[0])
			{
				SetCursor(gCursorClick);
				InvalidateRect(Window, NULL, FALSE);
			}
			else if (gRectSetSizeClick)
			{
				InvalidateRect(Window, NULL, FALSE);
			}
			else if (WParam & MK_LBUTTON)
			{
				BOOL Update = FALSE;

				if (gRectResize == WCAP_RESIZE_TL || gRectResize == WCAP_RESIZE_L || gRectResize == WCAP_RESIZE_BL)
				{
					// left moved
					gRectSelection[0].x = X;
					AdjustRectSizeMultipleOf2(0, 1);
					Update = TRUE;
				}
				else if (gRectResize == WCAP_RESIZE_TR || gRectResize == WCAP_RESIZE_R || gRectResize == WCAP_RESIZE_BR)
				{
					// right moved
					gRectSelection[1].x = X;
					AdjustRectSizeMultipleOf2(1, 0);
					Update = TRUE;
				}

				if (gRectResize == WCAP_RESIZE_TL || gRectResize == WCAP_RESIZE_T || gRectResize == WCAP_RESIZE_TR)
				{
					// top moved
					gRectSelection[0].y = Y;
					AdjustRectSizeMultipleOf2(0, 1);
					Update = TRUE;
				}
				else if (gRectResize == WCAP_RESIZE_BL || gRectResize == WCAP_RESIZE_B || gRectResize == WCAP_RESIZE_BR)
				{
					// bottom moved
					gRectSelection[1].y = Y;
					AdjustRectSizeMultipleOf2(1, 0);
					Update = TRUE;
				}

				if (gRectResize == WCAP_RESIZE_M)
				{
					// if moving whole rectangle update both
					int DX = X - gRectMousePos.x;
					int DY = Y - gRectMousePos.y;
					gRectMousePos = (POINT){ X, Y };

					gRectSelection[0].x += DX;
					gRectSelection[0].y += DY;
					gRectSelection[1].x += DX;
					gRectSelection[1].y += DY;

					Update = TRUE;
				}
				else if (gRectResize == WCAP_RESIZE_NONE)
				{
					// no resize means we're selecting initial rectangle
					gRectSelection[1].x = X;
					gRectSelection[1].y = Y;
					AdjustRectSizeMultipleOf2(1, 0);
					if (gRectSelection[0].x != gRectSelection[1].x && gRectSelection[0].y != gRectSelection[1].y)
					{
						// when we have non-zero size rectangle, we're good with initial stage
						gRectSelected = TRUE;
						Update = TRUE;
					}
				}

				if (Update)
				{
					InvalidateRect(Window, NULL, FALSE);
				}
			}
			else
			{
				int Resize = gRectSelected ? GetPointResize(X, Y) : WCAP_RESIZE_NONE;
				SetCursor(gCursorResize[Resize]);

				if (Resize == WCAP_RESIZE_NONE)
				{
					// in case hovering over resize text
					InvalidateRect(Window, NULL, FALSE);
				}
			}

			return 0;
		}
	}
	else if (Message == WM_TIMER)
	{
		if (gRecording)
		{
			// heartbeat for watchdog: increment on every timer tick so the watchdog
			// knows the main thread is still processing messages
			atomic_fetch_add(&gWatchdogHeartbeat, 1);

			if (WParam == WCAP_AUDIO_CAPTURE_TIMER)
			{
				EncodeCapturedAudio();
				return 0;
			}
			else if (WParam == WCAP_VIDEO_UPDATE_TIMER)
			{
				LARGE_INTEGER Time;
				QueryPerformanceCounter(&Time);
				Encoder_Update(&gEncoder, Time.QuadPart, gTickFreq.QuadPart);
				return 0;
			}
		}
	}
	else if (Message == WM_POWERBROADCAST)
	{
		if (WParam == PBT_APMQUERYSUSPEND)
		{
			if (gRecording)
			{
				if (LParam & 1)
				{
					// reject request to suspend when recording
					LOG_INFO("Rejecting suspend request (recording active)");
					return BROADCAST_QUERY_DENY;
				}
				else
				{
					// if cannot prevent suspend, need to stop recording
					LOG_WARN("System suspend forced - stopping recording");
					StopRecording();
				}
			}
			else
			{
				// allow to suspend when not recording
			}
		}
		return TRUE;
	}
	else if (Message == WM_WCAP_COMMAND)
	{
		// don't log mouse-move hover events, only real interactions
		if (LOWORD(LParam) != WM_MOUSEMOVE)
		{
			LOG_INFO("WM_WCAP_COMMAND: LParam=0x%08X", LParam);
		}
		if (LOWORD(LParam) == WM_RBUTTONUP)
		{
			LOG_INFO("Tray right-click: creating popup menu");
			HMENU Menu = CreatePopupMenu();
			Assert(Menu);

			if (gRecording)
			{
				AppendMenuW(Menu, MF_STRING, CMD_STOP, L"Stop Recording");
			}
			else
			{
				// enumerate available screens, sorted by stable GDI device number
				MonitorEntry Entries[WCAP_MAX_MONITORS];
				int Count = GetSortedMonitorList(Entries, WCAP_MAX_MONITORS);

				if (Count <= 1)
				{
					AppendMenuW(Menu, MF_STRING, CMD_SCREEN + 0, L"Start Recording");
				}
				else
				{
					for (int i = 0; i < Count; i++)
					{
						// first 10 characters of the display name (EDID name or "DISPLAYn")
						WCHAR ShortName[11];
						StrCpyNW(ShortName, MonitorDisplayName(&Entries[i]), _countof(ShortName));

						// when two screens share the same name (e.g. two identical monitors),
						// append the stable device number to tell them apart
						BOOL Duplicate = FALSE;
						for (int j = 0; j < Count; j++)
						{
							if (j != i && StrCmpNW(MonitorDisplayName(&Entries[i]), MonitorDisplayName(&Entries[j]), 10) == 0)
							{
								Duplicate = TRUE;
								break;
							}
						}

						WCHAR Name[128];
						if (Duplicate)
						{
							StrFormat(Name, L"Start Recording %ls (%d)", ShortName, Entries[i].DeviceNumber);
						}
						else
						{
							StrFormat(Name, L"Start Recording %ls", ShortName);
						}
						AppendMenuW(Menu, MF_STRING, CMD_SCREEN + i, Name);
					}
				}
			}

			AppendMenuW(Menu, MF_SEPARATOR, 0, NULL);
			AppendMenuW(Menu, MF_STRING, CMD_WCAP, WCAP_TITLE);
			AppendMenuW(Menu, MF_SEPARATOR, 0, NULL);
			AppendMenuW(Menu, MF_STRING | (gRecording ? MF_DISABLED : 0), CMD_SETTINGS, L"Settings");
			AppendMenuW(Menu, MF_STRING, CMD_QUIT, L"Exit");

			POINT Mouse;
			GetCursorPos(&Mouse);

			SetForegroundWindow(Window);
			LOG_INFO("Tray right-click: calling TrackPopupMenu (blocking)...");
			int Command = TrackPopupMenu(Menu, TPM_RETURNCMD | TPM_NONOTIFY, Mouse.x, Mouse.y, 0, Window, NULL);
			LOG_INFO("Tray right-click: TrackPopupMenu returned, Command=%d", Command);
			if (Command == CMD_STOP)
			{
				StopRecording();
			}
			else if (Command >= CMD_SCREEN && Command < CMD_SCREEN + WCAP_MAX_MONITORS)
			{
				if (gRectContext == NULL)
				{
					int Index = Command - CMD_SCREEN;
					LOG_INFO("Tray menu: start recording screen %d", Index + 1);
					gRecordingStarted = TRUE;
					CaptureMonitorByIndex(Index);
					gRecordingStarted = FALSE;
				}
			}
			else if (Command == CMD_WCAP)
			{
				ShellExecuteW(NULL, L"open", WCAP_URL, NULL, NULL, SW_SHOWNORMAL);
			}
			else if (Command == CMD_QUIT)
			{
				DestroyWindow(Window);
			}
			else if (Command == CMD_SETTINGS)
			{
				LOG_INFO("Tray right-click: showing settings dialog...");
				if (Config_ShowDialog(&gConfig))
				{
					Config_Save(&gConfig, gConfigPath);
					DisableHotKeys();
					EnableHotKeys();
					
					// apply logging setting immediately
					if (gConfig.EnableLog && !gLogInitialized)
					{
						Log__Init();
					}
					else if (!gConfig.EnableLog && gLogInitialized)
					{
						Log__Shutdown();
					}
				}
				LOG_INFO("Tray right-click: settings dialog closed");
			}

			DestroyMenu(Menu);
		}
		else if (LOWORD(LParam) == WM_LBUTTONDBLCLK)
		{
			LOG_INFO("Tray double-click: recording=%d", gRecording);
			if (!gRecording)
			{
				LOG_INFO("Tray double-click: showing settings dialog...");
				if (Config_ShowDialog(&gConfig))
				{
					Config_Save(&gConfig, gConfigPath);
					DisableHotKeys();
					EnableHotKeys();
					
					// apply logging setting immediately
					if (gConfig.EnableLog && !gLogInitialized)
					{
						Log__Init();
					}
					else if (!gConfig.EnableLog && gLogInitialized)
					{
						Log__Shutdown();
					}
				}
				LOG_INFO("Tray double-click: settings dialog closed");
			}
		}
		else if (LOWORD(LParam) == NIN_BALLOONUSERCLICK)
		{
			// Only open folder if we have a valid recording file
			// (prevents opening old folder when clicking tray icon after error notifications)
			if (gRecordingPath[0] && GetFileAttributesW(gRecordingPath) != INVALID_FILE_ATTRIBUTES)
			{
				ShowFileInFolder(gRecordingPath);
			}
		}
		return 0;
	}
	else if (Message == WM_HOTKEY)
	{
		if (gRecording)
		{
			LOG_INFO("Hotkey pressed during recording - stopping");
			StopRecording();
		}
		else if (!gRecordingStarted)
		{
			if (gRectContext == NULL)
			{
				if (WParam == HOT_RECORD_WINDOW)
				{
					LOG_INFO("Hotkey: record window");
					gRecordingStarted = TRUE;
					CaptureWindow();
					gRecordingStarted = FALSE;
				}
				else if (WParam == HOT_RECORD_MONITOR)
				{
					LOG_INFO("Hotkey: record monitor");
					gRecordingStarted = TRUE;
					CaptureMonitor();
					gRecordingStarted = FALSE;
				}
				else if (WParam == HOT_RECORD_REGION)
				{
					LOG_INFO("Hotkey: record region");
					gRecordingStarted = TRUE;
					CaptureRegionInit();
					gRecordingStarted = FALSE;
				}
			}
		}
		return 0;
	}
	else if (Message == WM_WCAP_TRAY_TITLE)
	{
		if (gRecording)
		{
			UINT64 FileSize;
			DWORD Bitrate, LengthMsec;
			Encoder_GetStats(&gEncoder, &Bitrate, &LengthMsec, &FileSize);

			WCHAR LengthText[128];
			StrFromTimeIntervalW(LengthText, _countof(LengthText), LengthMsec, 6);

			WCHAR SizeText[128];
			StrFormatByteSizeW(FileSize, SizeText, _countof(SizeText));

			WCHAR Text[1024];
			StrFormat(Text, L"Recording: %dx%d @ %.2f\nLength: %ls\nBitrate: %u kbit/s\nSize: %ls\nFramedrop: %u",
				gEncoder.OutputWidth, gEncoder.OutputHeight,
				(float)gEncoder.FramerateNum / (float)gEncoder.FramerateDen,
				LengthText,
				Bitrate,
				SizeText,
				gRecordingDroppedFrames);

			UpdateTrayTitle(Text);
		}
		return 0;
	}
	else if (Message == WM_WCAP_STOP_CAPTURE)
	{
		LOG_INFO("WM_WCAP_STOP_CAPTURE received");
		if (gRecording)
		{
			StopRecording();
		}
		return 0;
	}
	else if (Message == WM_WCAP_ALREADY_RUNNING)
	{
		ShowNotification(L"wcap is already running!", NULL, NIIF_INFO);
		return 0;
	}
	else if (Message == WM_TASKBARCREATED)
	{
		// in case taskbar was re-created (explorer.exe crashed) add our icon back
		AddTrayIcon(Window);
		return 0;
	}
	else if (Message == WM_ERASEBKGND)
	{
		return 1;
	}
	else if (Message == WM_PAINT)
	{
		PAINTSTRUCT Paint;
		HDC PaintContext = BeginPaint(Window, &Paint);

		HDC Context;
		HPAINTBUFFER BufferedPaint = BeginBufferedPaint(PaintContext, &Paint.rcPaint, BPBF_COMPATIBLEBITMAP, NULL, &Context);
		if (BufferedPaint)
		{
			if (gRectContext)
			{
				{
					int X = Paint.rcPaint.left;
					int Y = Paint.rcPaint.top;
					int W = Paint.rcPaint.right - Paint.rcPaint.left;
					int H = Paint.rcPaint.bottom - Paint.rcPaint.top;

					// draw darkened screenshot
					BitBlt(Context, X, Y, W, H, gRectDarkContext, X, Y, SRCCOPY);
				}

				if (gRectSelected)
				{
					// draw selected rectangle
					int X0 = min(gRectSelection[0].x, gRectSelection[1].x);
					int Y0 = min(gRectSelection[0].y, gRectSelection[1].y);
					int X1 = max(gRectSelection[0].x, gRectSelection[1].x);
					int Y1 = max(gRectSelection[0].y, gRectSelection[1].y);
					BitBlt(Context, X0, Y0, X1 - X0, Y1 - Y0, gRectContext, X0, Y0, SRCCOPY);

					RECT Rect = { X0 - 1, Y0 - 1, X1 + 1, Y1 + 1 };
					FrameRect(Context, &Rect, GetStockObject(WHITE_BRUSH));

					WCHAR Text[128];
					int TextLength = StrFormat(Text, L"%d x %d", X1 - X0, Y1 - Y0);

					SelectObject(Context, gFontBold);
					SetTextAlign(Context, TA_TOP | TA_RIGHT);
					SetTextColor(Context, RGB(255, 255, 255));
					SetBkMode(Context, TRANSPARENT);
					ExtTextOutW(Context, X1, Y1, 0, NULL, Text, TextLength, NULL);

					SelectObject(Context, gFontBold);
					SetTextAlign(Context, TA_BOTTOM | TA_LEFT);
					SetTextColor(Context, RGB(255, 255, 255));

					const WCHAR TextResize[] = L"Resize:  ";

					SIZE Size;
					GetTextExtentPoint32W(Context, TextResize, _countof(TextResize) - 1, &Size);
					ExtTextOutW(Context, X0, Y0, 0, NULL, TextResize, _countof(TextResize) - 1, NULL);

					int X = X0;
					SelectObject(Context, gFont);

					POINT CursorPos;
					GetCursorPos(&CursorPos);
					ScreenToClient(Window, &CursorPos);

					gRectSetSize[0] = gRectSetSize[1] = 0;

					int Sizes[][2] = { { 800, 600 }, { 1280, 720 }, { 1920, 1080 }, { 2560, 1440 } };
					for (int i=0; i<_countof(Sizes); i++)
					{
						X += Size.cx;

						TextLength = StrFormat(Text, L"%dx%d  ", Sizes[i][0], Sizes[i][1]);
						GetTextExtentPoint32W(Context, Text, TextLength, &Size);

						RECT Rect = { X, Y0 - Size.cy, X + Size.cx, Y0 };
						BOOL Hovering = PtInRect(&Rect, CursorPos);
						SetTextColor(Context, Hovering ? RGB(255, 255, 255) : RGB(192, 192, 192));
						ExtTextOutW(Context, X, Y0, 0, NULL, Text, TextLength, NULL);

						if (Hovering)
						{
							gRectSetSize[0] = Sizes[i][0];
							gRectSetSize[1] = Sizes[i][1];
							SetCursor(gCursorClick);
						}
					}
				}
				else
				{
					// draw initial message when no rectangle is selected
					SelectObject(Context, gFont);
					SelectObject(Context, GetStockObject(DC_PEN));
					SelectObject(Context, GetStockObject(DC_BRUSH));

					const WCHAR Line1[] = L"Select region with the mouse and press ENTER to start capture.";
					const WCHAR Line2[] = L"Press ESC to cancel.";

					const WCHAR* Lines[] = { Line1, Line2 };
					const int LineLengths[] = { _countof(Line1) - 1, _countof(Line2) - 1 };
					int Widths[_countof(Lines)];
					int Height;

					int TotalWidth = 0;
					int TotalHeight = 0;
					for (int i = 0; i < _countof(Lines); i++)
					{
						SIZE Size;
						GetTextExtentPoint32W(Context, Lines[i], LineLengths[i], &Size);
						Widths[i] = Size.cx;
						Height = Size.cy;
						TotalWidth = max(TotalWidth, Size.cx);
						TotalHeight += Size.cy;
					}
					TotalWidth += 2 * Height;
					TotalHeight += Height;

					int MsgX = (gRectWidth - TotalWidth) / 2;
					int MsgY = (gRectHeight - TotalHeight) / 2;

					SetDCPenColor(Context, RGB(255, 255, 255));
					SetDCBrushColor(Context, RGB(0, 0, 128));
					Rectangle(Context, MsgX, MsgY, MsgX + TotalWidth, MsgY + TotalHeight);

					SetTextAlign(Context, TA_TOP | TA_CENTER);
					SetTextColor(Context, RGB(255, 255, 0));
					SetBkMode(Context, TRANSPARENT);
					int Y = MsgY + Height / 2;
					int X = gRectWidth / 2;
					for (int i = 0; i < _countof(Lines); i++)
					{
						ExtTextOutW(Context, X, Y, 0, NULL, Lines[i], LineLengths[i], NULL);
						Y += Height;
					}
				}
			}
			else
			{
				RECT Rect;
				GetClientRect(Window, &Rect);

				HBRUSH BorderBrush = CreateSolidBrush(RGB(255, 255, 0));
				Assert(BorderBrush);
				FillRect(Context, &Rect, BorderBrush);
				DeleteObject(BorderBrush);

				Rect.left += WCAP_RECT_BORDER;
				Rect.top += WCAP_RECT_BORDER;
				Rect.right -= WCAP_RECT_BORDER;
				Rect.bottom -= WCAP_RECT_BORDER;

				HBRUSH ColorKeyBrush = CreateSolidBrush(RGB(255, 0, 255));
				Assert(ColorKeyBrush);
				FillRect(Context, &Rect, ColorKeyBrush);
				DeleteObject(ColorKeyBrush);

				FrameRect(Context, &Rect, GetStockObject(BLACK_BRUSH));
			}

			EndBufferedPaint(BufferedPaint, TRUE);
		}

		EndPaint(Window, &Paint);
		return 0;
	}

	return DefWindowProcW(Window, Message, WParam, LParam);
}

static bool OnCaptureFrame(ScreenCapture* Capture, ScreenCaptureFrame* Frame)
{
	if (Frame == NULL)
	{
		LOG_WARN("OnCaptureFrame: capture item closed (Frame==NULL), posting stop");
		PostMessageW(gWindow, WM_WCAP_STOP_CAPTURE, 0, 0);
		return true;
	}

	BOOL DoEncode = TRUE;
	DWORD LimitFramerate = gRecordingLimitFramerate;
	if (LimitFramerate != 0)
	{
		if (Frame->Time * LimitFramerate < gRecordingNextEncode)
		{
			DoEncode = FALSE;
		}
		else
		{
			if (gRecordingNextEncode == 0)
			{
				gRecordingNextEncode = Frame->Time * LimitFramerate;
			}
			gRecordingNextEncode += gTickFreq.QuadPart;
		}
	}

	// ignore frames if it comes from the past
	if (Frame->Time <= gRecordingLastFrame)
	{
		DoEncode = FALSE;
	}
	gRecordingLastFrame = Frame->Time;

	if (DoEncode)
	{
		if (!Encoder_NewFrame(&gEncoder, Frame->Texture, Frame->Rect, Frame->Time, gTickFreq.QuadPart))
		{
			// TODO: maybe highlight tray icon when droppped frames are increasing too much?
			gRecordingDroppedFrames++;
			if (gRecordingDroppedFrames <= 5 || (gRecordingDroppedFrames % 100) == 0)
			{
				LOG_WARN("Dropped video frame #%lu", gRecordingDroppedFrames);
			}
		}
	}

	if (gConfig.EnableLimitLength || gConfig.EnableLimitSize)
	{
		BOOL Stop = FALSE;

		if (gConfig.EnableLimitLength)
		{
			if (Frame->Time - gEncoder.StartTime >= (UINT64)(gConfig.LimitLength * gTickFreq.QuadPart))
			{
				LOG_INFO("Recording length limit reached (%lu sec)", gConfig.LimitLength);
				Stop = TRUE;
			}
		}
		if (gConfig.EnableLimitSize && !Stop)
		{
			UINT64 FileSize;
			DWORD Bitrate, LengthMsec;
			Encoder_GetStats(&gEncoder, &Bitrate, &LengthMsec, &FileSize);

			// reserve 0.5% for mp4 format overhead (probably an overestimate)
			if (1000 * FileSize >= (995ULL * gConfig.LimitSize) << 20)
			{
				LOG_INFO("Recording size limit reached (%lu MB, file=%llu bytes)", gConfig.LimitSize, FileSize);
				Stop = TRUE;
			}
		}

		if (Stop)
		{
			PostMessageW(gWindow, WM_WCAP_STOP_CAPTURE, 0, 0);
			return true;
		}
	}

	// update tray title with stats once every second
	if (gRecordingNextTooltip == 0)
	{
		gRecordingNextTooltip = Frame->Time + gTickFreq.QuadPart;
	}
	else if (Frame->Time >= gRecordingNextTooltip)
	{
		gRecordingNextTooltip += gTickFreq.QuadPart;

		// do the update, but not from frame callback to minimize time when texture is used
		PostMessageW(gWindow, WM_WCAP_TRAY_TITLE, 0, 0);
	}

	return true;
}

#ifndef NDEBUG
int WinMain(HINSTANCE instance, HINSTANCE previous, LPSTR cmdline, int cmdshow)
#else
void WinMainCRTStartup()
#endif
{
	// load config first to check if logging is enabled
	GetModuleFileNameW(NULL, gConfigPath, _countof(gConfigPath));
	PathRenameExtensionW(gConfigPath, L".ini");

	Config_Defaults(&gConfig);
	Config_Load(&gConfig, gConfigPath);

	// only enable logging if EnableLog=1 in the INI file
	// most users don't need it, and it writes to disk on every log call
	if (gConfig.EnableLog)
	{
		Log__Init();
	}
	LOG_INFO("=== wcap starting === " WCAP_CONFIG_TITLE);

	WNDCLASSEXW WindowClass =
	{
		.cbSize = sizeof(WindowClass),
		.lpfnWndProc = WindowProc,
		.hInstance = GetModuleHandleW(NULL),
		.lpszClassName = L"wcap_window_class",
	};

	HWND Existing = FindWindowW(WindowClass.lpszClassName, NULL);
	if (Existing)
	{
		PostMessageW(Existing, WM_WCAP_ALREADY_RUNNING, 0, 0);
		ExitProcess(0);
	}

	if (!ScreenCapture_IsSupported())
	{
		MessageBoxW(NULL, L"Windows 10 Version 1903, May 2019 Update (19H1) or newer is required!", WCAP_TITLE, MB_ICONEXCLAMATION);
		ExitProcess(0);
	}

	HR(CoInitializeEx(0, COINIT_APARTMENTTHREADED));

	ScreenCapture_Create(&gCapture, &OnCaptureFrame, false);
	Encoder_Init(&gEncoder);

	QueryPerformanceFrequency(&gTickFreq);

	gCursorArrow = LoadCursor(NULL, IDC_ARROW);
	gCursorClick = LoadCursor(NULL, IDC_HAND);
	gCursorResize[WCAP_RESIZE_NONE] = LoadCursor(NULL, IDC_CROSS);
	gCursorResize[WCAP_RESIZE_M]    = LoadCursor(NULL, IDC_SIZEALL);
	gCursorResize[WCAP_RESIZE_T]    = gCursorResize[WCAP_RESIZE_B]  = LoadCursor(NULL, IDC_SIZENS);
	gCursorResize[WCAP_RESIZE_L]    = gCursorResize[WCAP_RESIZE_R]  = LoadCursor(NULL, IDC_SIZEWE);
	gCursorResize[WCAP_RESIZE_TL]   = gCursorResize[WCAP_RESIZE_BR] = LoadCursor(NULL, IDC_SIZENWSE);
	gCursorResize[WCAP_RESIZE_TR]   = gCursorResize[WCAP_RESIZE_BL] = LoadCursor(NULL, IDC_SIZENESW);

	gFont = CreateFontW(-WCAP_UI_FONT_SIZE, 0, 0, 0, FW_NORMAL,
		FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
		CLEARTYPE_QUALITY, DEFAULT_PITCH, WCAP_UI_FONT);
	Assert(gFont);

	gFontBold = CreateFontW(-WCAP_UI_FONT_SIZE, 0, 0, 0, FW_BOLD,
		FALSE, FALSE, FALSE,DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
		CLEARTYPE_QUALITY, DEFAULT_PITCH, WCAP_UI_FONT);
	Assert(gFontBold);

	gIcon1 = LoadIconW(WindowClass.hInstance, MAKEINTRESOURCEW(1));
	gIcon2 = LoadIconW(WindowClass.hInstance, MAKEINTRESOURCEW(2));
	Assert(gIcon1 && gIcon2);

	WM_TASKBARCREATED = RegisterWindowMessageW(L"TaskbarCreated");
	Assert(WM_TASKBARCREATED);

	ATOM Atom = RegisterClassExW(&WindowClass);
	Assert(Atom);

	gWindow = CreateWindowExW(
		0, WindowClass.lpszClassName, WCAP_TITLE, WS_POPUP,
		CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
		NULL, NULL, WindowClass.hInstance, NULL);
	if (!gWindow)
	{
		ExitProcess(0);
	}
	if (!EnableHotKeys())
	{
		MessageBoxW(NULL,
			L"Cannot register wcap keyboard shortcuts.\nSome other application might already use shorcuts.\nPlease check & adjust the settings!",
			WCAP_TITLE, MB_ICONEXCLAMATION);
	}

	for (;;)
	{
		MSG Message;
		BOOL Result = GetMessageW(&Message, NULL, 0, 0);
		if (Result == 0)
		{
			ExitProcess(0);
		}
		Assert(Result > 0);

		TranslateMessage(&Message);
		DispatchMessageW(&Message);
	}
}
